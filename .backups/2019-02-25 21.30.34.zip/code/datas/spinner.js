import { Animatable, Data } from 'framer'

const overlayOpacity = Animatable(1)

export default Data({
  overlayOpacity,
})
