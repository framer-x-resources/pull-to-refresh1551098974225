import { animate } from 'framer'

import { labels } from '../datas'
import { sleep } from '../utils'

const animation = async () => {
  log('showPrevLabel!')
  labels.currentPage++
}

export default animation
