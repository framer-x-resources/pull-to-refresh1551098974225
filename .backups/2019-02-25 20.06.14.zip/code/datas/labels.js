import { Animatable, Data } from 'framer'

const labelNum = 5
const move = 70
const opacity = []
const currentPage = 4

for (let i = 0; i < labelNum; i++) {
  opacity.push(Animatable(1))
}

export default Data({
  labelNum,
  move,
  opacity,
  currentPage,
})
