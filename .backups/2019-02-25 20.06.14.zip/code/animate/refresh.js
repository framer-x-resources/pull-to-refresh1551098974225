import { animate } from 'framer'

import { body, hiddenField, labels } from '../datas'
import { sleep } from '../utils'

const animation = async () => {
  log('refresh!')
  animate.ease(body.top, 100)
  animate.ease(hiddenField.height, 100)
  labels.currentPage++
  await sleep(0.7)
  labels.currentPage++
  await sleep(0.7)
  labels.currentPage++
  await sleep(0.7)
  labels.currentPage++
  await sleep(0.7)
  labels.currentPage = 5
  await sleep(0.7)
  animate.ease(body.top, 0)
}

export default animation
