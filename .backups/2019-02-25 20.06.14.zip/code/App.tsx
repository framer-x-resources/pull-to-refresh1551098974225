import { Data, animate, Override, Animatable } from 'framer'
import { body, hiddenField, labels } from './datas'

window.log = console.log

export const Body: Override = () => {
  return {
    top: body.top,
  }
}

export const HiddenField: Override = () => {
  return {
    height: hiddenField.height,
  }
}

export const Label: Override = props => {
  let currentIndex = props.children[0].props.children[0].props.currentIndex
  return {
    // top: labels.top[currentIndex],
    opacity: labels.opacity[currentIndex],
  }
}

export const LabelPage: Override = props => {
  return {
    currentPage: labels.currentPage,
  }
}
