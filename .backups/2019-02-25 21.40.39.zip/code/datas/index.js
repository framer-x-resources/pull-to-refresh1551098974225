import body from './body'
import spinner from './spinner'

export { body, spinner }
