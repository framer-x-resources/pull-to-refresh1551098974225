import { Animatable, Data } from 'framer'

const labelNum = 5
const currentPage = 4
const top = Animatable(0)
const isRefreshing = false

export default Data({
  labelNum,
  currentPage,
  top,
  isRefreshing,
})
