import { Animatable, Data } from 'framer'

const labelNum = 5
const currentPage = 4

export default Data({
  labelNum,
  currentPage,
})
