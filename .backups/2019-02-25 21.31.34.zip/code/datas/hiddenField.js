import { Animatable, Data } from 'framer'

const height = Animatable(0)

export default Data({
  height,
})
