import { Animatable, Data } from 'framer'

const labelNum = 5
const move = 70
const currentPage = 4

export default Data({
  labelNum,
  move,
  currentPage,
})
