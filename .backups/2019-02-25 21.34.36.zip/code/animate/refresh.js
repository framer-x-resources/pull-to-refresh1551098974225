import { animate } from 'framer'

import { body, hiddenField, labels, spinner } from '../datas'
import { sleep } from '../utils'

const animation = async () => {
  log('refresh!')
  animate.ease(spinner.opacity, 1)
  await sleep(0.5)
  animate.ease(spinner.overlayOpacity, 0)
  animate.ease(body.top, 80)

  await sleep(2)

  animate.ease(spinner.overlayOpacity, 1)
  await sleep(0.5)
  animate.ease(spinner.opacity, 0)
  await sleep(0.5)

  await animate.ease(body.top, 0).finished

  labels.isRefreshing = false
}

export default animation
