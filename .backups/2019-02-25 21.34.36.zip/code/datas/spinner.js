import { Animatable, Data } from 'framer'

const opacity = Animatable(0)
const overlayOpacity = Animatable(1)

export default Data({
  opacity,
  overlayOpacity,
})
