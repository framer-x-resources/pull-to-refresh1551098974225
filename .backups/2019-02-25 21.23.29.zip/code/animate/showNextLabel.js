import { animate } from 'framer'

import { labels } from '../datas'
import { sleep } from '../utils'

const animation = async () => {
  log('showNextLabel!')
  labels.currentPage--
}

export default animation
