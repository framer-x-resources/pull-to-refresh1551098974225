import { Animatable, Data } from 'framer'

const scale = Animatable(0)
const overlayOpacity = Animatable(1)

export default Data({
  scale,
  overlayOpacity,
})
