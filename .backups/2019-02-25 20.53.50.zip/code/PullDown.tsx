import * as React from 'react'
import { PropertyControls, ControlType, Draggable, animate } from 'framer'
import styled, { css } from 'styled-components'
import { body, hiddenField, labels } from './datas'
import { showNextLabel, showPrevLabel, refresh } from './animate'

const Wrap = styled.div`
  width: 100%;
  height: 100%;
`
const StyledDraggable = styled(Draggable)`
  background: violet !important;
  width: 100% !important;
  height: 100% !important;
  opacity: 0;
`

// Define type of property
interface Props {}

var animStep = 0
var releaseAnimStep = 0
var tempY = 0

export class PullDown extends React.Component<Props> {
  state = { left: 0, top: 0 }

  // Set default properties
  static defaultProps = {}

  // Items shown in property panel
  static propertyControls: PropertyControls = {}

  onMove = e => {
    this.setState({ left: e.x, top: e.y })

    if (!labels.isRefreshing) {
      body.top.set(e.y)
      hiddenField.height.set(e.y)
    }

    if (tempY < e.y) {
      if (labels.labelNum > animStep + 1) {
        log('pull down')

        if (e.y > animStep * 20) {
          // animate image to bottom
          log('animate!', animStep)

          showNextLabel()
          animStep++
        }
      }
    } else if (tempY > e.y && !labels.isRefreshing) {
      log('release')
      if (e.y > 200) {
        log('refresh!!')
        refresh()
        labels.isRefreshing = true
      } else if (e.y < animStep * 20) {
        // animate image to bottom
        log('release animate!', animStep)
        showPrevLabel()
        animStep--
      }
    }
    tempY = e.y
  }

  render() {
    return (
      <Wrap>
        <StyledDraggable
          left={this.state.left}
          top={this.state.top}
          onMove={this.onMove}
        />
      </Wrap>
    )
  }
}
