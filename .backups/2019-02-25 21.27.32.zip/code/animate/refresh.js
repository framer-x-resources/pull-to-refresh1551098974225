import { animate } from 'framer'

import { body, hiddenField, labels, spinner } from '../datas'
import { sleep } from '../utils'

const animation = async () => {
  log('refresh!')
  animate.ease(spinner.overlayOpacity, 0)
}

export default animation
